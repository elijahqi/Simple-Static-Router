#!/bin/bash

sudo python p4.py
